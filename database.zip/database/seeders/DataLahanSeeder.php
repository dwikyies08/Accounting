<?php

namespace Database\Seeders;

use App\Models\DataLahan;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class DataLahanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $validClusterIds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
        $validPemasokIds = [1, 2, 3, 4, 5, 6];

        $data = [
            [
                'nama_tanah' => 'lahan perum BHR',
                'cluster_id' => in_array(3, $validClusterIds) ? 3 : 1,
                'tanggal_perolehan' => '2025-04-19',
                'pemasok_id' => in_array(1, $validPemasokIds) ? 1 : 1,
                'no_hp_tuan_tanah' => '081234123',
                'luas_area' => 1000,
                'harga_per_m2' => 1000000,
                'note' => null,
                'dicatat_sebagai' => true,
            ],
            // Tambahkan pengecekan serupa untuk entri lainnya...
        ];

        foreach ($data as $item) {
            DataLahan::create($item);
        }
    }
}
